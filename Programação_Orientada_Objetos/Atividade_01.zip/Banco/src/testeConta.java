
public class testeConta {
	public static void main(String[] args) {
	Conta conta = new Conta(303115.0, 0844.0, "Vila das Merc�s", 341.0, "Itau", 5.0);
	System.out.println("Conta: "+conta.toString());
}
}